<footer class="nav navbar-fixed-bottom">
            <b>&COPY; <a href="http://projectnotes.org">ProjectNotes</a></b>
            <br>
</footer>



</body>
</html>
